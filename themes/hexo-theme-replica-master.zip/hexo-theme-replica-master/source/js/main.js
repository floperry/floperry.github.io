new Vue({
	el: '#replica-app',
	data: {
		moment: moment
	}
});
